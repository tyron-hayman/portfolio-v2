import Head from 'next/head';
import 'bootstrap/dist/css/bootstrap.css';
import '../scss/main.css';

export default function Header() {
  return (
    <div className='container-fluid'>
      <nav className="navbar">
        <div className="container">
          <a className="navbar-brand" href="#">
            tyronhayman
          </a>
        </div>
      </nav>
    </div>
  )
}