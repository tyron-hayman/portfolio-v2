import Head from 'next/head';
import 'bootstrap/dist/css/bootstrap.css';
import '../scss/main.css';

export default function Work({ heading, projects }) {
  return (
    <div className='container-inner workContainer'>
      <div className='row justify-content-center'>
        <div className='col-lg-12'>
            <h2>Featured Work</h2>
        </div>
        <div className='col-lg-6'>
            <p>{heading}</p>
        </div>
      </div>
      <div className='row justify-content-between'>
      {projects.map((project, i) => {

            let projectStyle = { 
                background: `url(${project.image}) center center no-repeat`
            }

            return(
                    <div className="col-lg-6 projectBoxesWrap" key={i}>
                        <div className='projectImage' style={projectStyle}></div>
                        <div className='projectBoxes'>
                            <h3 className="projects-text">{project.name}</h3>
                            <p>{project.content}</p>
                            <ul>
                                <li>{project.attribution}</li>
                                <li>{project.date}</li>
                                <li><a href={project.link} target='_blank'>View</a></li>
                            </ul>
                        </div>
                    </div>
                )
      })}
      </div>
    </div>
  )
}